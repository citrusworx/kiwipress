<?php

// blank-template.php

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Headless Mode</title>
</head>
<body>
    <h1>Headless Mode Activated</h1>
    <p>
      This WordPress installation is in headless mode. Please access the content via the API.   
    </p>
</body> 